exports.handler = (event, context, callback) => {
    console.log('Hello, logs!');
    callback(null, 'great success');
}